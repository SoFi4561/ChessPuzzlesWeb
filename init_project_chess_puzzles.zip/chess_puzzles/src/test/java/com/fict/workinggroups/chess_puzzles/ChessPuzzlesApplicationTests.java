package com.fict.workinggroups.chess_puzzles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChessPuzzlesApplicationTests {

	@Test
	void contextLoads() {
	}

}
