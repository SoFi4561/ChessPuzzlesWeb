package com.fict.workinggroups.chess_puzzles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChessPuzzlesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChessPuzzlesApplication.class, args);
	}

}
